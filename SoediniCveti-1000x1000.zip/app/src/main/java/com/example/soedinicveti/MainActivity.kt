package com.example.soedinicveti

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.rgb(16,16,24)))
        setContentView(GameView())
    }

    inner class GameView : View(this) {
        private var level = 1
        private var completed = 0
        private var grid = 6
        private var cell = 0f
        private var zoom = 1f
        private var offX = 0f
        private var offY = 0f
        private var lastX = 0f
        private var lastY = 0f
        private var dragging = false

        private val palette = intArrayOf(
            Color.rgb(239,83,80), Color.rgb(66,165,245), Color.rgb(102,187,106),
            Color.rgb(255,202,40), Color.rgb(171,71,188), Color.rgb(38,198,218),
            Color.rgb(255,112,67), Color.rgb(236,64,122)
        )
        private val dots = HashMap<Pair<Int,Int>, Int>()
        private var activeColor = -1
        private var path = mutableListOf<Pair<Int,Int>>()
        private val solved = HashSet<Int>()
        private val prefs by lazy { getSharedPreferences("game", 0) }

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }

        init {
            level = prefs.getInt("level", 1).coerceIn(1,1000)
            generateLevel()
        }

        private fun generateLevel() {
            grid = when {
                level <= 100 -> 6 + (level / 10)
                level <= 300 -> 16 + ((level-100) / 10)
                level <= 500 -> 36 + ((level-300) / 8)
                level <= 750 -> 61 + ((level-500) / 6)
                else -> 103 + ((level-750) * 897 / 250)
            }.coerceIn(6,1000)
            dots.clear()
            solved.clear()
            path.clear()
            activeColor = -1

            val pairs = when {
                level < 50 -> 3
                level < 150 -> 4
                level < 300 -> 5
                level < 500 -> 6
                level < 750 -> 7
                else -> 8
            }.coerceAtMost(palette.size)

            // Deterministic, well-spread endpoints. They are generated without
            // allocating a million-cell array, so 1000x1000 remains lightweight.
            val r = Random(level.toLong() * 7919L)
            for (color in 0 until pairs) {
                var a: Pair<Int,Int>
                var b: Pair<Int,Int>
                do {
                    a = Pair(r.nextInt(grid), r.nextInt(grid))
                    b = Pair(r.nextInt(grid), r.nextInt(grid))
                } while (a == b || dots.containsKey(a) || dots.containsKey(b) ||
                    abs(a.first-b.first)+abs(a.second-b.second) < max(2, grid/5))
                dots[a] = color
                dots[b] = color
            }
            // Keep the view centered on the current playable region.
            zoom = if (grid <= 20) 1f else min(1f, 18f/grid.toFloat())
            offX = 0f; offY = 0f
            invalidate()
        }

        private fun boardSize() = min(width * .92f, height * .76f)
        private fun boardLeft() = (width - boardSize())/2f
        private fun boardTop() = 115f

        private fun screenX(col:Int):Float {
            val base = boardSize()/grid
            return boardLeft() + (col + .5f) * base * zoom + offX
        }
        private fun screenY(row:Int):Float {
            val base = boardSize()/grid
            return boardTop() + (row + .5f) * base * zoom + offY
        }

        private fun cellFromTouch(x:Float,y:Float):Pair<Int,Int>? {
            val base = boardSize()/grid/1f
            val col = floor((x - boardLeft() - offX)/(base*zoom)).toInt()
            val row = floor((y - boardTop() - offY)/(base*zoom)).toInt()
            return if (row in 0 until grid && col in 0 until grid) Pair(row,col) else null
        }

        override fun onDraw(c:Canvas) {
            c.drawColor(Color.rgb(16,16,24))
            text.textSize = 25f
            c.drawText("СОЕДИНИ ЦВЕТА", width/2f, 38f, text)
            text.textSize = 16f
            c.drawText("Уровень $level / 1000    •    Поле ${grid}×${grid}", width/2f, 65f, text)

            val bs = boardSize()
            paint.color = Color.rgb(34,34,48)
            c.drawRoundRect(boardLeft()-8, boardTop()-8, boardLeft()+bs+8, boardTop()+bs+8, 22f,22f,paint)

            c.save()
            c.clipRect(boardLeft(), boardTop(), boardLeft()+bs, boardTop()+bs)

            val base = bs/grid
            val step = base*zoom
            // Grid lines are drawn only for visible cells. This is important at 1000×1000.
            val firstCol = max(0, floor((-offX)/(step)).toInt()-1)
            val lastCol = min(grid-1, ceil((bs-offX)/step).toInt()+1)
            val firstRow = max(0, floor((-offY)/(step)).toInt()-1)
            val lastRow = min(grid-1, ceil((bs-offY)/step).toInt()+1)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (grid > 100) 0.7f else 1f
            paint.color = Color.rgb(52,52,70)
            for (i in firstCol..lastCol) {
                val x = boardLeft()+i*step+offX
                c.drawLine(x, boardTop(), x, boardTop()+bs, paint)
            }
            for (i in firstRow..lastRow) {
                val y = boardTop()+i*step+offY
                c.drawLine(boardLeft(), y, boardLeft()+bs, y, paint)
            }
            paint.style = Paint.Style.FILL

            if (path.size > 1) {
                line.strokeWidth = max(3f, min(22f, step*.45f))
                line.color = palette[activeColor]
                val pth = Path()
                pth.moveTo(screenX(path[0].second), screenY(path[0].first))
                for (k in 1 until path.size) pth.lineTo(screenX(path[k].second), screenY(path[k].first))
                c.drawPath(pth, line)
            }

            val radius = max(3f, min(20f, step*.23f))
            for ((p,color) in dots) {
                val x=screenX(p.second); val y=screenY(p.first)
                if (x < boardLeft()-30 || x > boardLeft()+bs+30 || y < boardTop()-30 || y > boardTop()+bs+30) continue
                paint.color = palette[color]
                c.drawCircle(x,y,radius,paint)
                paint.color = Color.WHITE
                c.drawCircle(x,y,max(1.5f,radius*.35f),paint)
            }
            c.restore()

            text.textSize = 14f
            text.color = Color.LTGRAY
            c.drawText("Щипок: масштаб • Перетаскивание: перемещение", width/2f, height-42f, text)
            c.drawText("Пройдено: $completed     Масштаб: ${"%.1f".format(zoom)}×", width/2f, height-20f, text)
            text.color = Color.WHITE
        }

        override fun onTouchEvent(e:MotionEvent):Boolean {
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX=e.x; lastY=e.y; dragging=false
                    cellFromTouch(e.x,e.y)?.let { p ->
                        val color=dots[p]
                        if (color != null) {
                            activeColor=color
                            path.clear(); path.add(p)
                            invalidate()
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_POINTER_DOWN -> return true
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {
                        val x1=e.getX(0); val y1=e.getY(0); val x2=e.getX(1); val y2=e.getY(1)
                        val dist=hypot(x2-x1,y2-y1)
                        val oldDist=hypot(lastX-e.getX(1),lastY-e.getY(1))
                        if (oldDist > 0) {
                            zoom=(zoom*(dist/oldDist)).coerceIn(.35f, 8f)
                            invalidate()
                        }
                        lastX=x1; lastY=y1
                        return true
                    }
                    val dx=e.x-lastX; val dy=e.y-lastY
                    if (activeColor < 0 || abs(dx)+abs(dy) > 8) {
                        offX += dx; offY += dy
                        dragging=true
                    }
                    lastX=e.x; lastY=e.y
                    if (activeColor >= 0 && !dragging) {
                        cellFromTouch(e.x,e.y)?.let { p ->
                            val prev=path.last()
                            if (p != prev && abs(p.first-prev.first)+abs(p.second-prev.second)==1 && !path.contains(p)) {
                                path.add(p); invalidate()
                            }
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (activeColor >= 0) {
                        val target=dots.entries.firstOrNull { it.value==activeColor && it.key != path.firstOrNull() }?.key
                        if (target != null && path.lastOrNull()==target) {
                            solved.add(activeColor)
                            completed = solved.size
                            if (completed >= dots.values.toSet().size) {
                                if (level < 1000) level++ else level=1000
                                prefs.edit().putInt("level",level).apply()
                                generateLevel()
                            }
                        } else path.clear()
                        activeColor=-1
                        invalidate()
                    }
                    return true
                }
            }
            return true
        }
    }
}
